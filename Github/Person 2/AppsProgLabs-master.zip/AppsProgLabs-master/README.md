# Applications Programming (48024)
Model Solutions to problems in Applications Programming a subject at UTS. 

Will upload after the lab each week xd. I will only upload once the lab has been completed by all classes (eg. Friday Afternoon) so please don't be mad at my Ryan. I like your keyboard. 
